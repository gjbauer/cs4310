
void print(const char* text);

int
main(int argc, char* argv[])
{
  if (argc == 1) {
    print("\x1b[41m plan: read from stdin \x1b[0m\x1b[K\n");
  }
  if (argc == 2) {
    print("\x1b[41m ");
    print(argv[1]);
    print(" \x1b[0m\x1b[K\n");
  }

  return 0;
}

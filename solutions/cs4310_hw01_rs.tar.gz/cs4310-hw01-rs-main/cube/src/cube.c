
int cube(int xx) {
	return xx * xx * xx;
};

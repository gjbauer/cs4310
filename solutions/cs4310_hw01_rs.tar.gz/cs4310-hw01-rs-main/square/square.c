long square (long x) {
	long k;
	k = x*x;
	return k;
}

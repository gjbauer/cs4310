#ifndef NUFS_STRING_H
#define NUFS_STRING_H
char*
split(const char *path, int n);
int
count_l(const char *path);
#endif

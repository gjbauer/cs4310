#ifndef MKFS_H
#define MKFS_H
void mkfs();
#endif

#ifndef HASH_H
#define HASH_H

unsigned int hash(const unsigned char *str);

#endif

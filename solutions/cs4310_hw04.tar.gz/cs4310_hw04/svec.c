/* This file is lecture notes from CS 3650, Fall 2018 */
/* Author: Nat Tuck */

#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>

#include "svec.h"

svec*
make_svec()
{
    svec* sv  = malloc(sizeof(svec));
    sv->data  = malloc(2 * sizeof(char*));
    sv->size  = 0;
    sv->cap   = 2;
    //sv->smode = 0;
    return sv;
}

int count_a(char *chunk)
{
	int i, j=0;
	for(i=0; i<3 && chunk[i]!=0; i++) if(chunk[i]=='a') j++;
	return j;
}

void a_chunks(svec *sv, FILE* fh)
{
	char trip[4];
	bool x = false;
	while (1) {
		char *line = fgets(trip, 4, fh);
		if(!line||line[0]=='\n'||strlen(line)<3)
			break;
		if (x==false) {
			fseek(fh, -1, SEEK_CUR);
			x=true;
		} else {
			fseek(fh, -2, SEEK_CUR);
			x=false;
		}
		chomp(line);
		svec_push_back(sv, line);
	}
}

int keyassign(svec* xs, int n, FILE* fh) {
	char buff[256];
	int k=0;

	while (1) {
		char* line = fgets(buff, 256, fh); 
		if (!line)
			break;
		int j=0;
		for(int i=0; i<256 && line[256]; i++) {
			if(j==3) {
				k+=1;
				j=0;
			}
			if(xs->data[n][0]==line[i]) j+=1;
			else if(xs->data[n][1]==line[i]) j+=1;
			else if(xs->data[n][2]==line[i]) j+=1;
		}
	}
	fseek(fh, 0, SEEK_SET);
	return k;
}

int keygen(svec* xs, int n, int mode, FILE* fh)
{
	switch (mode) {
	case 2:
		return keyassign(xs, n, fh);
	case 1:
		return count_a(xs->data[n]);
		break;
	case 0:
		return strlen(xs->data[n]);
		break;
	}
}



void
free_svec(svec* sv)
{
    for (int ii=sv->size-1; ii >=0; ii--) free(sv->data[ii]);
    free(sv->data);
    free(sv);
}

char*
svec_get(svec* sv, int ii)
{
    assert(ii >= 0 && ii < sv->size);
    return sv->data[ii];
}

void
svec_put(svec* sv, int ii, char* item)
{
    //assert(ii >= 0 && ii < sv->cap);
    //
	int i;
    	for (i=0; item[i++]!=0;);
    	sv->data[ii] = calloc(i, sizeof(char));
    	for (i=0; item[i]!=0; i++) sv->data[ii][i]=item[i];
	return;
}

void
svec_push_back(svec* sv, char* item)
{

    if (sv->size==sv->cap-1) {
	sv->cap*=2;
	char **data = malloc(2*sv->cap*sizeof(char*));
	for(int ii = sv->size-1; ii>=0; ii--) data[ii]=sv->data[ii];
	free(sv->data);
	sv->data=data;
	svec_put(sv, sv->size++, item);
    }
    else
    	svec_put(sv, sv->size++, item);
    return;
}

void
svec_swap(svec* sv, int ii, int jj)//, int mode)
{
	int i, j, size;
	char aa[128];
	for(i=0; sv->data[ii][i]!=0; i++) aa[i] = sv->data[ii][i];
	aa[i]=0;
	//if (mode==ID_MODE)
	//	j = sv->id_0[ii];
	free(sv->data[ii]);
	for(size=0; sv->data[jj][size]!=0; size++);
	sv->data[ii] = calloc(size+1, sizeof(char));
	for(i=0; sv->data[jj][i]!=0; i++) sv->data[ii][i]=sv->data[jj][i];
	sv->data[ii][i]=0;
	//if (mode==ID_MODE)
	//	sv->id_0[ii] = sv->id_0[jj];
	free(sv->data[jj]);
	for(size=0; aa[size]!=0; size++);
	sv->data[jj] = calloc(size+1, sizeof(char));
	for(i=0; aa[i]!=0; i++) sv->data[jj][i]=aa[i];
	sv->data[jj][i]=0;
	//if (mode==ID_MODE)
	//	sv->id_0[jj] = j;
	return;
}

void
svec_print(svec *sv, int mode, FILE* fh)
{
	for(int ii=0; ii<sv->size; ii++) {
		char *line = svec_get(sv, ii);
		switch (mode) {
			case 2:
			case 1:
				printf("%ld\t%s\n", keygen(sv, ii, mode, fh), line);
				break;
			default:
				printf("%s\n", line);
				break;
		}
	}
	return;
}

/* This file is lecture notes from CS 3650, Fall 2018 */
/* Author: Nat Tuck */

#ifndef SVEC_H
#define SVEC_H

#define STD_MODE	0	// Standard mode - when run with no extra arguments
#define A_MODE		1	// Count a's in letter groups of three
#define ID_MODE		2	// Count a group of idioms by their occurence in
				// a file...

typedef struct svec {
    int size;
    int cap;
    //int smode; // We no longer need this
    //FILE* fh;	// Complete current level to unlock these features....
    //int id_0[12];
    char** data;
} svec;

svec* make_svec();
void  free_svec(svec* sv);

char* svec_get(svec* sv, int ii);
void  svec_put(svec* sv, int ii, char* item);

void svec_push_back(svec* sv, char* item);
void svec_swap(svec* sv, int ii, int jj);

void svec_print(svec *sv, int mode, FILE* fh);

int keygen(svec *xs, int n, int mode, FILE* fh);

int count_a(char *line);

void chomp(char *);

void a_chunks(svec *sv, FILE* fh);

#endif

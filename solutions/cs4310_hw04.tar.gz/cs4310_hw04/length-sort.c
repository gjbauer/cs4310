#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "svec.h"

void
insertionSort(svec* xs, int mode, FILE* fh)
{
    for (int i=1; i<xs->size; i++) {
	    int j = i - 1;
	    int key = keygen(xs, i, mode, fh);

	    while(j >= 0 && keygen(xs, j, mode, fh) > key) {
		    svec_swap(xs, j+1, j);
		    j--;
	    }
    }
    return;
}

void
insertionSortD(svec *xs, int mode, FILE* fh)
{
	for (int i=1; i<xs->size; i++) {
		int j = i - 1;
		int key = keygen(xs, i, mode, fh);

		while(j >=0 && keygen(xs, j, mode, fh) < key) {
			svec_swap(xs, j+1, j);
			j--;
		}
	}
	return;
}

void
chomp(char* text)
{
    for(int ii = 0; text[ii]; ++ii) {
        if (text[ii] == '\n') {
            text[ii] = 0;
            return;
        }
    }
}

void standard(svec *sv, FILE* fh)
{
	char temp[128];
	while (1) {
		char *line;
		line = fgets(temp, 128, fh);
		if (!line || line[0]=='\n')
		{//|| (xs->smode==1 && a==1 && strlen(line)<3)) {
	        	break;
	        }

        	chomp(line);
       		svec_push_back(sv, line);
    	}
}

int
main(int argc, char* argv[])
{
    if (argc < 2) {
	// TODO: Update this to account for new use cases!! ;)
        printf("Usage:\n  %s input-file\n", argv[0]);
        return 1;
    }
    char* idioms[] = {"ing","ion", "ers", "tio", "ati", "ate", "ent", "ter", "ess", "est", "ies", "tin"};

    svec* xs = make_svec();

    FILE* fh;
    if (argc == 2) fh = fopen(argv[1], "r"); // Locked territory...
    else fh = fopen(argv[2], "r");
    
    if (!fh) {
        perror("open failed");
        return 1;
    }

    int mode=STD_MODE;
	
    if(argc==2) {
	   standard(xs, fh); 
    }
    else if (!strcmp(argv[1], "-a"))
    {
	    mode=A_MODE;
	    a_chunks(xs, fh);
    }
    else if (!strcmp(argv[1], "-id"))
    {
    	xs->data=idioms;
	xs->size=12;
	xs->cap=12;
    }

    if(mode==STD_MODE)
	    insertionSort(xs, mode, fh);
    else
    	insertionSortD(xs, mode, fh);

    //fclose(xs->fh);
    fclose(fh);

    svec_print(xs, mode, fh);

    free_svec(xs);
    return 0;
}

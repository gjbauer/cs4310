#!/usr/bin/perl
use 5.30.0;
use warnings FATAL => 'all';
use autodie qw(:all);
use feature qw(signatures);
no warnings "experimental::signatures";

use Test::Simple tests => 15;

my @files = `find . -type f`;
my $bins = 0;
for my $file (@files) {
    chomp $file;
    my $type = `file "$file"`;
    if ($type =~ /ELF/ || $type =~ /stripped/) {
        say("# You submitted a binary: $file");
        unlink($file);
        $bins++;
    }
}

ok($bins == 0, "no binaries submitted");


run_quiet("make clean");
run_quiet("make");

for my $base (qw(01 02 03 04 05 06 07)) {
    test_case($base);
}

run_quiet("make clean");


sub run_quiet($cmd) {
    system(qq{$cmd 2>&1 > /dev/null});
}

use IO::Handle;

sub test_case($base) {
    my $have = qx{./colorize tests/${base}a.md};
    my $have2 = qx{./colorize < tests/${base}a.md};
    my $want = qx{cat tests/${base}b.txt};

    ok($have eq $want, "expected output for colorize ./tests/${base}a.md");
    ok($have2 eq $want, "expected output for colorize < ./tests/${base}a.md");

    if ($have ne $want) {
        say("#");
        say("# Output for ./colorize ${base}a.md doesn't match ${base}b.txt");
        say("# Manually test and compare results.");
        say("#");
    }
    if ($have2 ne $want) {
        say("#");
        say("# Output for ./colorize < ${base}a.md doesn't match ${base}b.txt");
        say("# Manually test and compare results.");
        say("#");
    }
}

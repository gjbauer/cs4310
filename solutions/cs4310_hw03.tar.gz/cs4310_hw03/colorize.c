typedef short size_t;
int open(char *filename, int flags);
void read(unsigned int fd, const char *buf, size_t);
int close(int fd);
void print(const char* text);

int changedmode=0;

void printmode(int mode)
{
	if (changedmode==1)
		print("\x1b[0m\x1b[K");
	if (mode==2)
		print("\x1b[45m");
	else if (mode==1)
		print("\x1b[46m");
	return;
}

void printline(char *buf, int start, int mode)
{
	printmode(mode);
	char cc[2];
	int i;
	for(i=start; buf[i]!='\n' && buf[i]!='\0'; i++)
	{
		cc[0]=buf[i];
		if (cc[0]==0x5B)
		{
			print("\x1b[34m");
			print(cc);
		} else if (cc[0]==0x5D)
		{
			print(cc);
			print("\x1b[0m\x1b[K");
		} else
		{
			print(cc);
		}
	}
	if (mode>0)
		print(" ");
	if (changedmode!=0||buf[i+1]!=0||mode>0)
	{
		cc[0]=buf[i];
		print(cc);
	}
	return;
}

void readfile(char *buf, int start)
{
	int i, j, k=0, l;

	for(i=start; buf[i]!='\n' && buf[i]!='\0'; i++);
	for(j=start; buf[j]=='#'; j++, k++);
	printline(buf, j, k);
	for(j=start, l=0; buf[j]=='#'; j++, l++);
	if (l==0)
		changedmode=0;
	else
		changedmode=1;
	if (buf[i]=='\n'&&buf[i+1]!='\0')
		readfile(buf, i+1);
	else
		return;
}

int
main(int argc, char* argv[])
{
  int fd;
  if (argc == 1)
	if (argv[2]==0)
		print("\x1b[41m plan: read from stdin \x1b[0m\x1b[K\n");
  if (argc == 2)
    fd = open(argv[1], 0);
  if (argc == 3)
	fd = open(argv[2],0);
  if (argc > 0)
  {
    /*if (fd<0) //Check if file exists...would have to edit syscall wrapper to implement...	
    {
	    print("ERROR: Could not open file!");
	    return -1;
    }
    else
    {*/
    	char buf[16384];
    	read(fd, buf, 16384);
    	readfile(buf, 0);
    	close(fd);
    //}
  	if (changedmode==1)
  		print("\x1b[0m\x1b[K");
  	else
		print("\n");
  }
  return 0;
}

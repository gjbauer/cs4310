#!/bin/bash

for n in {1..5}; 
do
    touch "mnt/"$n".nums"
done

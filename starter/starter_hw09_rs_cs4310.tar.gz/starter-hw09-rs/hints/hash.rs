use crate::directory;

pub fn hash(name: [char; directory::DIR_NAME]) -> usize {
	// TODO : Implement a has function...
}


#include <stdio.h>
#include <sys/stat.h>

#include "aok.h"

int
main(int argc, char *argv[])
{
    int rv;

    if (argc != 2) {
        fprintf(stderr, "Usage: %s input.txt\n", argv[0]);
        return 1;
    }

    struct stat sb;

    rv = stat(argv[1], &sb);
    aok(rv);

    printf("the input file is %ld kB\n", 1 + (sb.st_size / 1024));

    return 0;
}
